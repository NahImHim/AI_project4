#pragma once
#include "BehaviorNode.h"

class L_PlayJungleSound : public BaseNode<L_PlayJungleSound>
{
protected:
    virtual void on_enter() override;
};
